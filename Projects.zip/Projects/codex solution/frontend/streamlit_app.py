import os
import requests
import streamlit as st
import networkx as nx
import plotly.graph_objects as go


API_URL = os.getenv("BIOREASON_API_URL", "http://localhost:8000")

st.set_page_config(page_title="BioReason-X", layout="wide")
st.title("BioReason-X")


def post_analyze(mutation: str) -> dict:
    response = requests.post(f"{API_URL}/analyze", json={"mutation": mutation}, timeout=120)
    response.raise_for_status()
    return response.json()


def render_graph(graph_payload: dict) -> None:
    graph = nx.MultiDiGraph()
    for node in graph_payload.get("nodes", []):
        graph.add_node(node["id"], label=node["label"], node_type=node["type"])
    for edge in graph_payload.get("edges", []):
        graph.add_edge(edge["source"], edge["target"], relation=edge["relation"])
    if not graph.nodes:
        st.info("No graph entities found.")
        return

    pos = nx.spring_layout(graph, seed=7, k=0.8)
    edge_x, edge_y = [], []
    annotations = []
    for source, target, data in graph.edges(data=True):
        x0, y0 = pos[source]
        x1, y1 = pos[target]
        edge_x.extend([x0, x1, None])
        edge_y.extend([y0, y1, None])
        annotations.append(
            dict(
                x=(x0 + x1) / 2,
                y=(y0 + y1) / 2,
                text=data["relation"],
                showarrow=False,
                font=dict(size=10, color="#4b5563"),
            )
        )

    node_types = nx.get_node_attributes(graph, "node_type")
    color_map = {
        "Mutation": "#dc2626",
        "Gene": "#2563eb",
        "Protein": "#7c3aed",
        "Pathway": "#059669",
        "Disease": "#ea580c",
        "Drug": "#0891b2",
        "Publication": "#64748b",
    }
    node_x = [pos[node][0] for node in graph.nodes]
    node_y = [pos[node][1] for node in graph.nodes]
    labels = [graph.nodes[node]["label"] for node in graph.nodes]
    colors = [color_map.get(node_types.get(node, ""), "#111827") for node in graph.nodes]

    figure = go.Figure()
    figure.add_trace(
        go.Scatter(
            x=edge_x,
            y=edge_y,
            mode="lines",
            line=dict(width=1, color="#9ca3af"),
            hoverinfo="none",
        )
    )
    figure.add_trace(
        go.Scatter(
            x=node_x,
            y=node_y,
            mode="markers+text",
            text=labels,
            textposition="top center",
            marker=dict(size=18, color=colors, line=dict(width=1, color="#ffffff")),
            hovertext=[f"{label}<br>{node_types.get(node, '')}" for node, label in zip(graph.nodes, labels)],
            hoverinfo="text",
        )
    )
    figure.update_layout(
        height=650,
        showlegend=False,
        margin=dict(l=10, r=10, t=10, b=10),
        plot_bgcolor="#ffffff",
        xaxis=dict(visible=False),
        yaxis=dict(visible=False),
        annotations=annotations,
    )
    st.plotly_chart(figure, use_container_width=True)


mutation = st.sidebar.text_input("Mutation", "BRCA1 c.5266dupC")
run = st.sidebar.button("Analyze", type="primary")

if run or "analysis" not in st.session_state:
    with st.spinner("Running structured biomedical reasoning..."):
        st.session_state.analysis = post_analyze(mutation)

analysis = st.session_state.analysis
tabs = st.tabs(["Results", "Reasoning Trace", "Knowledge Graph", "Evidence Explorer"])

with tabs[0]:
    st.subheader("Mutation Analysis")
    st.json(analysis["mutation"], expanded=False)
    st.subheader("Gene and Protein Impact")
    st.write(analysis["gene_protein"]["function"])
    st.subheader("Pathways and Disease Associations")
    st.write(", ".join(analysis["pathway"]["pathways"]) or "No pathway found")
    st.write(", ".join(analysis["pathway"]["diseases"]) or "No disease association found")
    st.subheader("Therapy Recommendations")
    for therapy in analysis["therapies"]:
        st.markdown(f"**{therapy['drug']}** -> {therapy['target']}")
        st.write(therapy["rationale"])
    st.metric("Confidence Score", analysis["validation"]["confidence_score"])
    for caveat in analysis["validation"]["caveats"]:
        st.warning(caveat)

with tabs[1]:
    for step in analysis["reasoning_trace"]:
        st.markdown(f"**{step['step']}. {step['conclusion']}**")
        st.caption("Evidence: " + ", ".join(step["evidence_ids"]))

with tabs[2]:
    render_graph(analysis["graph"])

with tabs[3]:
    seen = {}
    for section in ["mutation", "gene_protein", "pathway"]:
        for evidence in analysis[section].get("evidence", []):
            seen[evidence["id"]] = evidence
    for evidence in analysis.get("literature", []):
        seen[evidence["id"]] = evidence
    for therapy in analysis["therapies"]:
        for evidence in therapy["evidence"]:
            seen[evidence["id"]] = evidence
    for evidence in seen.values():
        with st.expander(f"{evidence['source']}: {evidence['title']}"):
            st.write(evidence["text"])
            if evidence.get("url"):
                st.link_button("Open source", evidence["url"])
