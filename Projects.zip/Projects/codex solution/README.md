# BioReason-X

BioReason-X is an explainable AI platform that performs structured biomedical reasoning:

`Genomic Mutation -> Gene -> Protein -> Biological Pathway -> Disease -> Therapy`

It is built for hackathon deployment on AMD MI300X with ROCm-compatible local inference through vLLM, while remaining runnable end-to-end on a laptop using bundled sample data.

## Features

- FastAPI backend with `/analyze`, `/reason`, `/therapy`, `/graph`, and `/health`
- Streamlit frontend with mutation input, results, reasoning trace, graph, and evidence explorer
- LangGraph multi-agent workflow
- Lightweight NetworkX biomedical knowledge graph
- ChromaDB biomedical RAG with BGE embeddings and deterministic fallback retrieval
- Sample ClinVar, Reactome, UniProt, DrugBank subset, and PubMed abstract data
- Evidence-backed therapy rationale and confidence scoring

## Quickstart

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m backend.ingestion.build_indexes --reset
uvicorn backend.api.main:app --reload --port 8000
```

In another terminal:

```bash
streamlit run frontend/streamlit_app.py
```

Try the sample mutation:

```text
BRCA1 c.5266dupC
```

## Local LLM

For MI300X/vLLM deployment, start Qwen 2.5 14B Instruct as an OpenAI-compatible server:

```bash
vllm serve Qwen/Qwen2.5-14B-Instruct \
  --host 0.0.0.0 \
  --port 8001 \
  --dtype bfloat16 \
  --max-model-len 8192
```

Then set:

```bash
set BIOREASON_LLM_BASE_URL=http://localhost:8001/v1
set BIOREASON_LLM_MODEL=Qwen/Qwen2.5-14B-Instruct
```

The code is intentionally guarded: if the LLM or vector DB is unavailable, the sample reasoning path still runs using structured datasets and lexical retrieval.

## Docker

```bash
docker compose up --build
```

## Project Layout

```text
backend/
  agents/       LangGraph agent implementations and prompts
  workflows/    End-to-end reasoning graph
  rag/          Chroma/BGE and hybrid retrieval
  graph/        NetworkX biomedical graph
  api/          FastAPI app
  schemas/      Pydantic models
  services/     Dataset and LLM utilities
  ingestion/    Data ingestion and index building
frontend/       Streamlit UI
data/           Sample biomedical datasets
tests/          Unit tests
```

## Important Note

BioReason-X is a research decision-support prototype. It does not provide medical advice. Therapy outputs must be reviewed by qualified clinical experts and checked against current clinical guidelines.
