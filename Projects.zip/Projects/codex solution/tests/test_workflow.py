from backend.workflows.reasoning_workflow import BioReasonWorkflow


def test_brca1_sample_reasoning_end_to_end():
    response = BioReasonWorkflow().analyze("BRCA1 c.5266dupC")
    assert response.mutation.gene == "BRCA1"
    assert response.mutation.clinical_significance == "Pathogenic"
    assert response.gene_protein.protein.startswith("Breast cancer")
    assert response.pathway.pathways
    assert any(therapy.drug == "Olaparib" for therapy in response.therapies)
    assert response.validation.confidence_score > 0.5
    assert len(response.reasoning_trace) == 6
