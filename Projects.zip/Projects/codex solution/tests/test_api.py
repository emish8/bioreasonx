from fastapi.testclient import TestClient
from backend.api.main import app


def test_health():
    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_analyze_endpoint():
    client = TestClient(app)
    response = client.post("/analyze", json={"mutation": "BRCA1 c.5266dupC"})
    assert response.status_code == 200
    body = response.json()
    assert body["mutation"]["gene"] == "BRCA1"
    assert body["therapies"]
