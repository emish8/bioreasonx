from typing import Any, Literal
from pydantic import BaseModel, Field


EntityType = Literal["Mutation", "Gene", "Protein", "Pathway", "Disease", "Drug", "Publication"]


class Evidence(BaseModel):
    id: str
    source: str
    title: str
    text: str
    url: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class MutationRequest(BaseModel):
    mutation: str = Field(..., examples=["BRCA1 c.5266dupC"])


class MutationFinding(BaseModel):
    mutation: str
    gene: str
    variant: str
    mutation_type: str
    clinical_significance: str
    disease: str | None = None
    evidence: list[Evidence] = Field(default_factory=list)


class GeneProteinFinding(BaseModel):
    gene: str
    protein: str
    function: str
    uniprot_id: str | None = None
    evidence: list[Evidence] = Field(default_factory=list)


class PathwayFinding(BaseModel):
    pathways: list[str]
    diseases: list[str]
    evidence: list[Evidence] = Field(default_factory=list)


class TherapyFinding(BaseModel):
    drug: str
    target: str
    rationale: str
    evidence: list[Evidence] = Field(default_factory=list)


class ValidationFinding(BaseModel):
    confidence_score: float = Field(ge=0, le=1)
    caveats: list[str]
    evidence_coverage: dict[str, int]


class ReasoningStep(BaseModel):
    step: int
    conclusion: str
    evidence_ids: list[str] = Field(default_factory=list)


class AnalysisResponse(BaseModel):
    mutation: MutationFinding
    gene_protein: GeneProteinFinding
    pathway: PathwayFinding
    literature: list[Evidence]
    therapies: list[TherapyFinding]
    validation: ValidationFinding
    reasoning_trace: list[ReasoningStep]
    graph: dict[str, Any]


class GraphNode(BaseModel):
    id: str
    label: str
    type: EntityType
    properties: dict[str, Any] = Field(default_factory=dict)


class GraphEdge(BaseModel):
    source: str
    target: str
    relation: str


class GraphResponse(BaseModel):
    nodes: list[GraphNode]
    edges: list[GraphEdge]
