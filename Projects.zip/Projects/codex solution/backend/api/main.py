from functools import lru_cache
from fastapi import FastAPI
from backend.graph.biomedical_graph import BiomedicalKnowledgeGraph
from backend.schemas.models import AnalysisResponse, GraphResponse, MutationRequest
from backend.workflows.reasoning_workflow import BioReasonWorkflow

app = FastAPI(title="BioReason-X", version="0.1.0")


@lru_cache
def workflow() -> BioReasonWorkflow:
    return BioReasonWorkflow()


@lru_cache
def knowledge_graph() -> BiomedicalKnowledgeGraph:
    return BiomedicalKnowledgeGraph()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "BioReason-X"}


@app.post("/analyze", response_model=AnalysisResponse)
def analyze(request: MutationRequest) -> AnalysisResponse:
    return workflow().analyze(request.mutation)


@app.post("/reason", response_model=AnalysisResponse)
def reason(request: MutationRequest) -> AnalysisResponse:
    return workflow().analyze(request.mutation)


@app.post("/therapy")
def therapy(request: MutationRequest) -> dict:
    response = workflow().analyze(request.mutation)
    return {"mutation": request.mutation, "therapies": [therapy.model_dump() for therapy in response.therapies]}


@app.get("/graph", response_model=GraphResponse)
def graph() -> GraphResponse:
    return knowledge_graph().to_response()
