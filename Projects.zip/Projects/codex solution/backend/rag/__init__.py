"""Retrieval augmented generation utilities."""
