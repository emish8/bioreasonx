from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import re
from backend.config import get_settings
from backend.schemas.models import Evidence
from backend.services.data_repository import DataRepository


@dataclass
class IndexedDocument:
    id: str
    source: str
    title: str
    text: str
    url: str | None
    metadata: dict


class BiomedicalRetriever:
    """Chroma/BGE retriever with a lexical fallback for offline sample runs."""

    def __init__(self, data_dir: Path | None = None) -> None:
        self.settings = get_settings()
        self.repo = DataRepository(data_dir)
        self.docs = self._load_documents()
        self._collection = None
        self._init_chroma()

    def _load_documents(self) -> list[IndexedDocument]:
        docs: list[IndexedDocument] = []
        for row in self.repo.pubmed():
            docs.append(
                IndexedDocument(
                    id=str(row["pmid"]),
                    source="PubMed",
                    title=row["title"],
                    text=row["abstract"],
                    url=f"https://pubmed.ncbi.nlm.nih.gov/{row['pmid']}/",
                    metadata={"pmid": str(row["pmid"]), "genes": row.get("genes", "")},
                )
            )
        return docs

    def _init_chroma(self) -> None:
        try:
            import chromadb
            from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

            self.settings.chroma_dir.mkdir(parents=True, exist_ok=True)
            client = chromadb.PersistentClient(path=str(self.settings.chroma_dir))
            embedding_fn = SentenceTransformerEmbeddingFunction(model_name=self.settings.embedding_model)
            self._collection = client.get_or_create_collection(
                name=self.settings.collection_name,
                embedding_function=embedding_fn,
                metadata={"hnsw:space": "cosine"},
            )
            if self._collection.count() == 0 and self.docs:
                self._collection.add(
                    ids=[doc.id for doc in self.docs],
                    documents=[doc.text for doc in self.docs],
                    metadatas=[
                        {"source": doc.source, "title": doc.title, "url": doc.url or "", **doc.metadata}
                        for doc in self.docs
                    ],
                )
        except Exception:
            self._collection = None

    def search(self, query: str, k: int = 5) -> list[Evidence]:
        chroma_hits = self._search_chroma(query, k)
        if chroma_hits:
            return chroma_hits
        return self._search_lexical(query, k)

    def _search_chroma(self, query: str, k: int) -> list[Evidence]:
        if self._collection is None:
            return []
        try:
            result = self._collection.query(query_texts=[query], n_results=k)
            hits: list[Evidence] = []
            for idx, doc_text in enumerate(result["documents"][0]):
                meta = result["metadatas"][0][idx]
                hits.append(
                    Evidence(
                        id=str(result["ids"][0][idx]),
                        source=meta.get("source", "PubMed"),
                        title=meta.get("title", ""),
                        text=doc_text,
                        url=meta.get("url") or None,
                        metadata=meta,
                    )
                )
            return hits
        except Exception:
            return []

    def _search_lexical(self, query: str, k: int) -> list[Evidence]:
        query_terms = set(re.findall(r"[a-zA-Z0-9]+", query.lower()))
        scored: list[tuple[int, IndexedDocument]] = []
        for doc in self.docs:
            terms = set(re.findall(r"[a-zA-Z0-9]+", f"{doc.title} {doc.text}".lower()))
            scored.append((len(query_terms & terms), doc))
        scored.sort(key=lambda item: item[0], reverse=True)
        return [
            Evidence(
                id=doc.id,
                source=doc.source,
                title=doc.title,
                text=doc.text,
                url=doc.url,
                metadata=doc.metadata,
            )
            for score, doc in scored[:k]
            if score > 0
        ]
