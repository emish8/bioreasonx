from typing import Any
from backend.graph.biomedical_graph import BiomedicalKnowledgeGraph
from backend.schemas.models import AnalysisResponse, ReasoningStep


class ConsensusAgent:
    name = "consensus"

    def __init__(self, graph: BiomedicalKnowledgeGraph | None = None) -> None:
        self.graph = graph or BiomedicalKnowledgeGraph()

    def run(self, state: dict[str, Any]) -> dict[str, Any]:
        mutation = state["mutation"]
        gene_protein = state["gene_protein"]
        pathway = state["pathway"]
        therapies = state.get("therapies", [])
        literature = state.get("literature", [])
        trace = [
            ReasoningStep(
                step=1,
                conclusion=f"{mutation.mutation} was interpreted as {mutation.clinical_significance}.",
                evidence_ids=[e.id for e in mutation.evidence],
            ),
            ReasoningStep(
                step=2,
                conclusion=f"{mutation.gene} encodes {gene_protein.protein}; variant impact is assessed against protein function.",
                evidence_ids=[e.id for e in gene_protein.evidence],
            ),
            ReasoningStep(
                step=3,
                conclusion=f"Affected pathways include {', '.join(pathway.pathways) or 'none found'}.",
                evidence_ids=[e.id for e in pathway.evidence],
            ),
            ReasoningStep(
                step=4,
                conclusion=f"Disease associations include {', '.join(pathway.diseases or [mutation.disease or 'none found'])}.",
                evidence_ids=[e.id for e in pathway.evidence + mutation.evidence],
            ),
            ReasoningStep(
                step=5,
                conclusion=f"Therapy candidates: {', '.join(t.drug for t in therapies) or 'none found'}.",
                evidence_ids=[e.id for therapy in therapies for e in therapy.evidence],
            ),
            ReasoningStep(
                step=6,
                conclusion=f"Evidence validation produced confidence {state['validation'].confidence_score:.2f}.",
                evidence_ids=[e.id for e in literature],
            ),
        ]
        graph = self.graph.traverse(f"mutation:{mutation.mutation}", depth=4).model_dump()
        state["response"] = AnalysisResponse(
            mutation=mutation,
            gene_protein=gene_protein,
            pathway=pathway,
            literature=literature,
            therapies=therapies,
            validation=state["validation"],
            reasoning_trace=trace,
            graph=graph,
        )
        return state
