from typing import Any
from backend.rag.retriever import BiomedicalRetriever


class LiteratureAgent:
    name = "literature"

    def __init__(self, retriever: BiomedicalRetriever | None = None) -> None:
        self.retriever = retriever or BiomedicalRetriever()

    def run(self, state: dict[str, Any]) -> dict[str, Any]:
        mutation = state["mutation"]
        query = " ".join(
            [
                mutation.gene,
                mutation.variant,
                mutation.clinical_significance,
                " ".join(state["pathway"].pathways),
                "therapy disease",
            ]
        )
        state["literature"] = self.retriever.search(query, k=5)
        return state
