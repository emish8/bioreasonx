from typing import Any
from backend.schemas.models import Evidence, TherapyFinding
from backend.services.data_repository import DataRepository


class TherapyAgent:
    name = "therapy"

    def __init__(self, repo: DataRepository | None = None) -> None:
        self.repo = repo or DataRepository()

    def run(self, state: dict[str, Any]) -> dict[str, Any]:
        gene = state["mutation"].gene
        protein = state["gene_protein"].protein
        rows = self.repo.drugs_by_target(gene) + self.repo.drugs_by_target(protein)
        literature = state.get("literature", [])
        therapies: list[TherapyFinding] = []
        seen: set[str] = set()
        for row in rows:
            if row["drug"] in seen:
                continue
            seen.add(row["drug"])
            evidence: list[Evidence] = [
                Evidence(
                    id=f"drugbank:{row['drugbank_id']}",
                    source="DrugBank subset",
                    title=f"{row['drug']} targets {row['target_protein']}",
                    text=row["mechanism"],
                    metadata={"drugbank_id": row["drugbank_id"], "status": row["status"]},
                )
            ]
            evidence.extend(literature[:2])
            therapies.append(
                TherapyFinding(
                    drug=row["drug"],
                    target=row["target_protein"],
                    rationale=(
                        f"{row['drug']} is supported because it targets {row['target_protein']} "
                        f"or exploits defective {gene}-linked DNA repair biology. Status: {row['status']}."
                    ),
                    evidence=evidence,
                )
            )
        state["therapies"] = therapies
        return state
