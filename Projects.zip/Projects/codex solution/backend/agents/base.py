from typing import Any, Protocol


class Agent(Protocol):
    name: str

    def run(self, state: dict[str, Any]) -> dict[str, Any]:
        ...
