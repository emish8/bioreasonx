from typing import Any
from backend.schemas.models import Evidence, GeneProteinFinding
from backend.services.data_repository import DataRepository


class GeneProteinAgent:
    name = "gene_protein"

    def __init__(self, repo: DataRepository | None = None) -> None:
        self.repo = repo or DataRepository()

    def run(self, state: dict[str, Any]) -> dict[str, Any]:
        gene = state["mutation"].gene
        row = self.repo.uniprot_by_gene(gene)
        if row:
            evidence = [
                Evidence(
                    id=f"uniprot:{row['uniprot_id']}",
                    source="UniProt",
                    title=f"{row['gene']} encodes {row['protein']}",
                    text=row["function"],
                    url=f"https://www.uniprot.org/uniprotkb/{row['uniprot_id']}/entry",
                    metadata={"uniprot_id": row["uniprot_id"]},
                )
            ]
            finding = GeneProteinFinding(
                gene=gene,
                protein=row["protein"],
                function=row["function"],
                uniprot_id=row["uniprot_id"],
                evidence=evidence,
            )
        else:
            finding = GeneProteinFinding(gene=gene, protein="Unknown", function="No UniProt record found.")
        state["gene_protein"] = finding
        return state
