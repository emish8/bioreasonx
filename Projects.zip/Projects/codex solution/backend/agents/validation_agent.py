from typing import Any
from backend.schemas.models import ValidationFinding


class EvidenceValidationAgent:
    name = "evidence_validation"

    def run(self, state: dict[str, Any]) -> dict[str, Any]:
        coverage = {
            "mutation": len(state["mutation"].evidence),
            "gene_protein": len(state["gene_protein"].evidence),
            "pathway": len(state["pathway"].evidence),
            "literature": len(state.get("literature", [])),
            "therapy": sum(len(t.evidence) for t in state.get("therapies", [])),
        }
        present = sum(1 for value in coverage.values() if value > 0)
        confidence = min(0.95, 0.35 + present * 0.12)
        if "pathogenic" in state["mutation"].clinical_significance.lower():
            confidence += 0.05
        confidence = round(min(confidence, 0.98), 2)
        caveats = [
            "Therapy suggestions are decision-support hypotheses, not medical advice.",
            "Recommendations require review against current clinical guidelines and patient context.",
        ]
        if not state.get("therapies"):
            caveats.append("No drug-target mapping was found in the local DrugBank subset.")
        state["validation"] = ValidationFinding(
            confidence_score=confidence,
            caveats=caveats,
            evidence_coverage=coverage,
        )
        return state
