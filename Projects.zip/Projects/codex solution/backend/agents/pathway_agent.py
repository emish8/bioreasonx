from typing import Any
from backend.schemas.models import Evidence, PathwayFinding
from backend.services.data_repository import DataRepository


class PathwayAgent:
    name = "pathway"

    def __init__(self, repo: DataRepository | None = None) -> None:
        self.repo = repo or DataRepository()

    def run(self, state: dict[str, Any]) -> dict[str, Any]:
        gene = state["mutation"].gene
        rows = self.repo.reactome_by_gene(gene)
        evidence = [
            Evidence(
                id=f"reactome:{row['reactome_id']}",
                source="Reactome",
                title=row["pathway"],
                text=row["description"],
                url=f"https://reactome.org/content/detail/{row['reactome_id']}",
                metadata={"reactome_id": row["reactome_id"]},
            )
            for row in rows
        ]
        state["pathway"] = PathwayFinding(
            pathways=sorted({row["pathway"] for row in rows}),
            diseases=sorted({row["disease"] for row in rows}),
            evidence=evidence,
        )
        return state
