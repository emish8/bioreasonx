from __future__ import annotations

import re
from typing import Any
from backend.schemas.models import Evidence, MutationFinding
from backend.services.data_repository import DataRepository


class MutationAnalysisAgent:
    name = "mutation_analysis"

    def __init__(self, repo: DataRepository | None = None) -> None:
        self.repo = repo or DataRepository()

    def run(self, state: dict[str, Any]) -> dict[str, Any]:
        mutation = state["input_mutation"].strip()
        row = self.repo.clinvar_by_mutation(mutation)
        if row:
            variant = row["variant"]
            gene = row["gene"]
            significance = row["clinical_significance"]
            disease = row["disease"]
            mutation_type = row["mutation_type"]
            evidence = [
                Evidence(
                    id=f"clinvar:{row['variation_id']}",
                    source="ClinVar",
                    title=f"ClinVar interpretation for {mutation}",
                    text=row["summary"],
                    url=f"https://www.ncbi.nlm.nih.gov/clinvar/variation/{row['variation_id']}/",
                    metadata={"variation_id": str(row["variation_id"])},
                )
            ]
        else:
            match = re.match(r"([A-Za-z0-9]+)\s+(.+)", mutation)
            gene = match.group(1).upper() if match else "UNKNOWN"
            variant = match.group(2) if match else mutation
            significance = "Uncertain significance"
            disease = None
            mutation_type = "Unknown"
            evidence = []

        state["mutation"] = MutationFinding(
            mutation=mutation,
            gene=gene,
            variant=variant,
            mutation_type=mutation_type,
            clinical_significance=significance,
            disease=disease,
            evidence=evidence,
        )
        return state
