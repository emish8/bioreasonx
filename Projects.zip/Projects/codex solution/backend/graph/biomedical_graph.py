from __future__ import annotations

import networkx as nx
from backend.schemas.models import GraphEdge, GraphNode, GraphResponse
from backend.services.data_repository import DataRepository


class BiomedicalKnowledgeGraph:
    def __init__(self, repo: DataRepository | None = None) -> None:
        self.repo = repo or DataRepository()
        self.graph = nx.MultiDiGraph()
        self._build()

    def _add_node(self, node_id: str, label: str, node_type: str, **properties: str) -> None:
        self.graph.add_node(node_id, label=label, type=node_type, properties=properties)

    def _build(self) -> None:
        for row in self.repo.table("clinvar/sample_clinvar.csv").to_dict("records"):
            mutation_id = f"mutation:{row['mutation']}"
            gene_id = f"gene:{row['gene']}"
            disease_id = f"disease:{row['disease']}"
            self._add_node(mutation_id, row["mutation"], "Mutation", significance=row["clinical_significance"])
            self._add_node(gene_id, row["gene"], "Gene")
            self._add_node(disease_id, row["disease"], "Disease")
            self.graph.add_edge(mutation_id, gene_id, relation="affects")
            self.graph.add_edge(gene_id, disease_id, relation="associated_with")

        for row in self.repo.table("uniprot/sample_uniprot.csv").to_dict("records"):
            gene_id = f"gene:{row['gene']}"
            protein_id = f"protein:{row['protein']}"
            self._add_node(gene_id, row["gene"], "Gene")
            self._add_node(protein_id, row["protein"], "Protein", uniprot_id=row["uniprot_id"])
            self.graph.add_edge(gene_id, protein_id, relation="encodes")

        for row in self.repo.table("reactome/sample_reactome.csv").to_dict("records"):
            protein_id = f"protein:{row['protein']}"
            pathway_id = f"pathway:{row['pathway']}"
            disease_id = f"disease:{row['disease']}"
            self._add_node(pathway_id, row["pathway"], "Pathway", reactome_id=row["reactome_id"])
            self._add_node(disease_id, row["disease"], "Disease")
            self.graph.add_edge(protein_id, pathway_id, relation="participates_in")
            self.graph.add_edge(pathway_id, disease_id, relation="implicated_in")

        for row in self.repo.table("drugbank/sample_drugbank.csv").to_dict("records"):
            drug_id = f"drug:{row['drug']}"
            protein_id = f"protein:{row['target_protein']}"
            self._add_node(drug_id, row["drug"], "Drug", mechanism=row["mechanism"])
            self.graph.add_edge(drug_id, protein_id, relation="targets")

        for row in self.repo.pubmed():
            pub_id = f"publication:{row['pmid']}"
            self._add_node(pub_id, row["title"], "Publication", pmid=str(row["pmid"]))
            for gene in str(row.get("genes", "")).split(";"):
                gene = gene.strip()
                if gene:
                    self._add_node(f"gene:{gene}", gene, "Gene")
                    self.graph.add_edge(pub_id, f"gene:{gene}", relation="supports")

    def traverse(self, start_id: str, depth: int = 3) -> GraphResponse:
        if start_id not in self.graph:
            return GraphResponse(nodes=[], edges=[])
        visited = nx.single_source_shortest_path_length(self.graph.to_undirected(), start_id, cutoff=depth)
        sub = self.graph.subgraph(visited.keys())
        return self.to_response(sub)

    def to_response(self, graph: nx.MultiDiGraph | None = None) -> GraphResponse:
        graph = graph or self.graph
        nodes = [
            GraphNode(
                id=node_id,
                label=data.get("label", node_id),
                type=data.get("type", "Gene"),
                properties=data.get("properties", {}),
            )
            for node_id, data in graph.nodes(data=True)
        ]
        edges = [
            GraphEdge(source=source, target=target, relation=data["relation"])
            for source, target, data in graph.edges(data=True)
        ]
        return GraphResponse(nodes=nodes, edges=edges)
