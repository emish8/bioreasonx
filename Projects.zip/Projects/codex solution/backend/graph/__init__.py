"""Knowledge graph utilities."""
