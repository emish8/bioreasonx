from functools import lru_cache
from pathlib import Path
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="BIOREASON_", env_file=".env", extra="ignore")

    data_dir: Path = Field(default=Path("data"))
    chroma_dir: Path = Field(default=Path(".chroma"))
    llm_base_url: str | None = None
    llm_api_key: str = "not-needed"
    llm_model: str = "Qwen/Qwen2.5-14B-Instruct"
    embedding_model: str = "BAAI/bge-small-en-v1.5"
    collection_name: str = "bioreason_evidence"


@lru_cache
def get_settings() -> Settings:
    return Settings()
