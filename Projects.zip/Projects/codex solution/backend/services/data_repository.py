from pathlib import Path
import pandas as pd
from backend.config import get_settings


class DataRepository:
    """Loads small tabular biomedical sources and exposes typed lookups."""

    def __init__(self, data_dir: Path | None = None) -> None:
        self.data_dir = data_dir or get_settings().data_dir
        self._cache: dict[str, pd.DataFrame] = {}

    def table(self, name: str) -> pd.DataFrame:
        if name not in self._cache:
            path = self.data_dir / name
            self._cache[name] = pd.read_csv(path)
        return self._cache[name]

    def clinvar_by_mutation(self, mutation: str) -> dict | None:
        df = self.table("clinvar/sample_clinvar.csv")
        hit = df[df["mutation"].str.lower() == mutation.lower()]
        return None if hit.empty else hit.iloc[0].to_dict()

    def uniprot_by_gene(self, gene: str) -> dict | None:
        df = self.table("uniprot/sample_uniprot.csv")
        hit = df[df["gene"].str.upper() == gene.upper()]
        return None if hit.empty else hit.iloc[0].to_dict()

    def reactome_by_gene(self, gene: str) -> list[dict]:
        df = self.table("reactome/sample_reactome.csv")
        return df[df["gene"].str.upper() == gene.upper()].to_dict("records")

    def drugs_by_target(self, protein_or_gene: str) -> list[dict]:
        df = self.table("drugbank/sample_drugbank.csv")
        mask = (df["target_gene"].str.upper() == protein_or_gene.upper()) | (
            df["target_protein"].str.upper() == protein_or_gene.upper()
        )
        return df[mask].to_dict("records")

    def pubmed(self) -> list[dict]:
        return self.table("pubmed/sample_pubmed.csv").to_dict("records")
