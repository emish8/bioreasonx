import requests
from backend.config import get_settings


class LocalLLMClient:
    """Minimal OpenAI-compatible client for vLLM-served Qwen."""

    def __init__(self) -> None:
        self.settings = get_settings()

    def complete(self, system: str, user: str, temperature: float = 0.1) -> str:
        if not self.settings.llm_base_url:
            return ""
        url = self.settings.llm_base_url.rstrip("/") + "/chat/completions"
        payload = {
            "model": self.settings.llm_model,
            "temperature": temperature,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        }
        try:
            response = requests.post(
                url,
                json=payload,
                headers={"Authorization": f"Bearer {self.settings.llm_api_key}"},
                timeout=45,
            )
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except requests.RequestException:
            return ""
