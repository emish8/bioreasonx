from typing import Any
from backend.agents.consensus_agent import ConsensusAgent
from backend.agents.gene_agent import GeneProteinAgent
from backend.agents.literature_agent import LiteratureAgent
from backend.agents.mutation_agent import MutationAnalysisAgent
from backend.agents.pathway_agent import PathwayAgent
from backend.agents.therapy_agent import TherapyAgent
from backend.agents.validation_agent import EvidenceValidationAgent
from backend.schemas.models import AnalysisResponse


class BioReasonWorkflow:
    """LangGraph workflow with a sequential fallback API for lean environments."""

    def __init__(self) -> None:
        self.agents = [
            MutationAnalysisAgent(),
            GeneProteinAgent(),
            PathwayAgent(),
            LiteratureAgent(),
            TherapyAgent(),
            EvidenceValidationAgent(),
            ConsensusAgent(),
        ]
        self._graph = self._build_langgraph()

    def _build_langgraph(self) -> Any:
        try:
            from langgraph.graph import END, StateGraph

            graph = StateGraph(dict)
            for agent in self.agents:
                graph.add_node(agent.name, agent.run)
            for previous, current in zip(self.agents, self.agents[1:]):
                graph.add_edge(previous.name, current.name)
            graph.set_entry_point(self.agents[0].name)
            graph.add_edge(self.agents[-1].name, END)
            return graph.compile()
        except Exception:
            return None

    def analyze(self, mutation: str) -> AnalysisResponse:
        state: dict[str, Any] = {"input_mutation": mutation}
        if self._graph is not None:
            state = self._graph.invoke(state)
        else:
            for agent in self.agents:
                state = agent.run(state)
        return state["response"]
