import argparse
import shutil
from backend.config import get_settings
from backend.graph.biomedical_graph import BiomedicalKnowledgeGraph
from backend.rag.retriever import BiomedicalRetriever


def main() -> None:
    parser = argparse.ArgumentParser(description="Build BioReason-X vector and graph indexes.")
    parser.add_argument("--reset", action="store_true", help="Delete existing Chroma index first.")
    args = parser.parse_args()
    settings = get_settings()
    if args.reset and settings.chroma_dir.exists():
        shutil.rmtree(settings.chroma_dir)
    retriever = BiomedicalRetriever()
    graph = BiomedicalKnowledgeGraph()
    print(f"Indexed {len(retriever.docs)} evidence documents")
    print(f"Built graph with {graph.graph.number_of_nodes()} nodes and {graph.graph.number_of_edges()} edges")


if __name__ == "__main__":
    main()
